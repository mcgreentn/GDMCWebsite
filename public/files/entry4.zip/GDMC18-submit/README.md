# GDMC18
Entry for the Generative Design in Minecraft Competition http://gendesignmc.engineering.nyu.edu/

To try it out, get the [Minecraft Editor](https://github.com/mcgreentn/GDMC) provided for the competition and clone this repo into the 'stock-filters' directory. The script should show up as 'Settlement Generator' in the list of filters.
